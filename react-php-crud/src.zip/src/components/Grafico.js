import React, { useState, useEffect } from 'react'
import { Chart } from 'react-google-charts'
import api from '../api'

export default function Grafico() {
  const [mediat, setMediat] = useState(0)
  const [mediau, setMediau] = useState(0)
  const [medial, setMedial] = useState(0)
  const [median, setMedian] = useState(0)

  const [temp, setTemp] = useState([
    ['x', 'Carregando...'],
    [0, 0],
  ])

  const [umi, setUmi] = useState([
    ['x', 'Carregando...'],
    [0, 0],
  ])

  const [lumi, setLumi] = useState([
    ['x', 'Carregando...'],
    [0, 0],
  ])

  const [nh3, setNh3] = useState([
    ['x', 'Carregando...'],
    [0, 0],
  ])

  useEffect(() => {
    // effect
    // return () => {
    //   cleanup
    // }
    let oi = setTimeout(() => {
      api
        .post("php-react/all-users.php")
        .then((response) => {
          if (response.status === 200) {
            let test = [['a', 'e'], [1, 10], [2, 10], [3, 10], [4, 10], [5, 10]]
            let t = [['a', 'Temperatura (ºC)']]
            let u = [['a', 'Umidade (%)']]
            let l = [['a', 'Luminosidade']]
            let n = [['a', 'Nível de amônia (ppm)']]
            response.data.dados.map(e => {
              t.push([+e.id, +e.temp])
              u.push([+e.id, +e.umi])
              l.push([+e.id, +e.lumi])
              n.push([+e.id, +e.nh3])
            })

            let soma = (array) => {
              let total = array.slice(1, array.lenght).reduce((total, n) => {
                return total + n[1]
              }, 0)
              
              return total
            }

            let total_elementos = response.data.dados.length
            // console.log(typeof response.data.dados.length)
            let media = array => +(soma(array) / total_elementos).toFixed(2)
            
            setMediat(media(t))
            setMediau(media(u))
            setMedial(media(l))
            setMedian(media(n))

            console.log(mediat, mediau, medial, median)

            // setMediat(response.data.dados.length)
            setTemp(t)
            setUmi(u)
            setLumi(l)
            setNh3(n)
          }
        })
        .catch((error) => {
          console.log("Ocorreu um erro ao buscar os items");
        });
    }, 2000);

    // return () => clearTimeout(oi)
  }, [temp])

  let graficotemp = <Chart
  widthMin = {'700px'}
  height = {'400px'}
  chartType = "LineChart"
  loader = {<div> Carregando gráfico... </div>}
  data = {temp}
  options = {
    {
      colors: ['#fd7e14', '#6f42c1'],
      legend: {position: 'top'},
      // title: 'Temperatura (ºC)',
      // hAxis: { title: 'Time' },
      // vAxis: { title: 'Popularity' },
    }
  }
  rootProps = {{'data-testid': '1'}}
  /> 

  let graficoumi = <Chart
  // widthMax = {'45%'}
  height = {'400px'}
  chartType = "LineChart"
  loader = {<div> Carregando gráfico... </div>}
    data = {umi}
    options = {
      {
        colors: ['#dc3545', '#198754'],
        legend: {position: 'top'},
        // title: 'Temperatura (ºC)',
        // hAxis: {
        //   title: 'Time',
        // },
        // vAxis: {
        //   title: 'Popularity',
        // },
      }
    }
    rootProps = {{'data-testid': '1'}}
    />

    let graficolumi = <Chart
    // width = {'900px'}
    height = {'400px'}
    chartType = "LineChart"
    loader = {<div> Carregando gráfico... </div>}
      data = {lumi}
      options = {
        {
          colors: ['#20c997', '#d63384'],
          legend: {position: 'top'},
          // title: 'Temperatura (ºC)',
          // hAxis: {
          //   title: 'Time',
          // },
          // vAxis: {
          //   title: 'Popularity',
          // },
        }
      }
      rootProps = {{'data-testid': '1'}}
      />

    let graficonh3 =  <Chart
    // width = {'900px'}
    height = {'400px'}
    chartType = "LineChart"
    loader = {<div> Carregando gráfico... </div>}
      data = {nh3}
      options = {
        {
          colors: ['#3D00CC', '#8000FF'],
          legend: {position: 'top'},
          // title: 'Temperatura (ºC)',
          // hAxis: {
          //   title: 'Time',
          // },
          // vAxis: {
          //   title: 'Popularity',
          // },
        }
      }
      rootProps = {{'data-testid': '1'}}
      />

  return ( 
    <center>
      <div className="card">
        <h5 className="mt-3" >Médias</h5>
        <div className="card-body" >
          <div className="row">
            <div className="col" style={{ color: '#fd7e14' }} >
              <p>Temperatura</p>
              <h4>{mediat}</h4>
            </div>
            <div className="col"style={{ color: '#dc3545' }} >
              <p>Umidade</p>
              <h4>{mediau}</h4>
            </div>
            <div className="col" style={{ color: '#20c997' }} >
              <p>Luminosidade</p>
              <h4>{medial}</h4>
            </div>
            <div className="col" style={{ color: '#3D00CC' }} >
              <p>Amoônia</p>
              <h4>{median}</h4>
            </div>
          </div>
        </div>
      </div> 

      <div className="container">
        <div className="row">
          <div className="col">
            {graficotemp}
          </div>
          <div className="col">
            {graficoumi}
          </div>
        </div>
        <div className="row">
          <div className="col">
            {graficolumi}
          </div>
          <div className="col">
            {graficonh3}
          </div>
        </div>
      </div>     
    </center>
    )
  }