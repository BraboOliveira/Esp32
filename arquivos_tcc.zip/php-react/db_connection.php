<?php
$db_conn = mysqli_connect("vendebelem.com.mysql","vendebelem_comesp_data","284801","vendebelem_comesp_data");